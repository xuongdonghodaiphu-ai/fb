import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const action = searchParams.get("action");
  const user_id = searchParams.get("user_id");
  const where: any = {};
  if (action) where.action = action;
  if (user_id) where.user_id = user_id;
  const logs = await db.auditLog.findMany({ where, orderBy: { created_at: "desc" }, take: 100 });
  return NextResponse.json(logs);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { user_id, action, target_type, target_id, metadata } = body;
  const log = await db.auditLog.create({ data: { user_id, action, target_type, target_id, metadata } });
  return NextResponse.json(log);
}
