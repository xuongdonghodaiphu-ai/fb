import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { email, password } = body;
  // Mock auth - in production verify hashed password
  const user = await db.user.findUnique({ where: { email } });
  if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

  // Set cookie session
  const res = NextResponse.json({ user: { id: user.id, email: user.email, role: user.role, name: user.name } });
  res.cookies.set("fb_os_session", `session_${user.id}_${Date.now()}`, { httpOnly: true, maxAge: 60 * 60 * 24 * 7 });
  return res;
}

export async function GET(req: NextRequest) {
  const session = req.cookies.get("fb_os_session")?.value;
  if (!session) return NextResponse.json({ user: null }, { status: 401 });
  // Parse mock
  return NextResponse.json({ session, valid: true });
}

export async function DELETE() {
  const res = NextResponse.json({ success: true });
  res.cookies.set("fb_os_session", "", { maxAge: 0 });
  return res;
}
