import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(req: NextRequest, { params }: { params: { id: string } }) {
  const conversationId = params.id;
  const body = await req.json();
  const { tag_id } = body;
  const currentUserId = "user_sale_1";

  const existing = await db.conversationTag.findUnique({ where: { conversation_id_tag_id: { conversation_id: conversationId, tag_id } } as any });
  if (existing) return NextResponse.json(existing);

  const ct = await db.conversationTag.create({ data: { conversation_id: conversationId, tag_id, assigned_by: currentUserId } });

  await db.auditLog.create({
    data: { user_id: currentUserId, action: "ASSIGN_TAG", target_type: "Conversation", target_id: conversationId, metadata: { tag_id } },
  });

  return NextResponse.json(ct);
}

export async function DELETE(req: NextRequest, { params }: { params: { id: string } }) {
  const conversationId = params.id;
  const { searchParams } = new URL(req.url);
  const tagId = searchParams.get("tag_id");
  if (!tagId) return NextResponse.json({ error: "tag_id required" }, { status: 400 });

  await db.conversationTag.delete({ where: { conversation_id_tag_id: { conversation_id: conversationId, tag_id: tagId } } as any });
  return NextResponse.json({ success: true });
}

export async function GET(req: NextRequest, { params }: { params: { id: string } }) {
  const tags = await db.conversationTag.findMany({ where: { conversation_id: params.id }, include: { tag: true } });
  return NextResponse.json(tags);
}
