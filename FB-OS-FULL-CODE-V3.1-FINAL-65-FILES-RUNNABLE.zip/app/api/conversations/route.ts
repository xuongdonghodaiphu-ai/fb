import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const page_id = searchParams.get("page_id");
  const assigned_to_user_id = searchParams.get("assigned_to_user_id");
  const has_phone = searchParams.get("has_phone");
  const has_order = searchParams.get("has_order");
  const q = searchParams.get("q");
  const page = parseInt(searchParams.get("page") || "1");
  const limit = parseInt(searchParams.get("limit") || "20");

  const where: any = {};
  if (page_id) where.page_id = page_id;
  if (assigned_to_user_id) where.assigned_to_user_id = assigned_to_user_id;
  if (has_phone === "true") where.has_phone = true;
  if (has_phone === "false") where.has_phone = false;
  if (has_order === "true") where.has_order = true;
  if (has_order === "false") where.has_order = false;
  if (q) where.OR = [{ customer_name: { contains: q, mode: "insensitive" } }, { last_message_content: { contains: q, mode: "insensitive" } }];

  const [items, total] = await Promise.all([
    db.conversation.findMany({
      where,
      orderBy: { last_message_at: "desc" },
      skip: (page - 1) * limit,
      take: limit,
      include: { tags: { include: { tag: true } } },
    }),
    db.conversation.count({ where }),
  ]);

  // Lock 5 phút logic: if locked_until > now, keep lock
  const now = new Date();
  const withLock = items.map((c: any) => ({
    ...c,
    is_locked: c.locked_until && new Date(c.locked_until) > now,
  }));

  return NextResponse.json({ items: withLock, total, page, totalPages: Math.ceil(total / limit) });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { page_id, customer_id, customer_name } = body;
  const conv = await db.conversation.create({
    data: { page_id, customer_id, customer_name, last_message_content: "Bắt đầu hội thoại", last_message_at: new Date() },
  });
  return NextResponse.json(conv);
}
