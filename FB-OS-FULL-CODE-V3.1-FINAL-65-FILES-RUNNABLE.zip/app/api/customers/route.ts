import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const page_id = searchParams.get("page_id");
  const q = searchParams.get("q");

  // Customers derived from conversations
  const where: any = {};
  if (page_id) where.page_id = page_id;
  if (q) where.customer_name = { contains: q, mode: "insensitive" };

  const customers = await db.conversation.findMany({
    where,
    distinct: ["customer_id"],
    select: { customer_id: true, customer_name: true, page_id: true, has_phone: true, has_order: true },
    take: 100,
  });

  return NextResponse.json(customers);
}
