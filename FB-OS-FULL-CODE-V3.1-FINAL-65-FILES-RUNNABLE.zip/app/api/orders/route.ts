import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { buildPrimary, buildFanout } from "@/lib/capi";
import { addCapiJob } from "@/lib/queue";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { conversation_id, items, total_amount, phone } = body;

    // Mock current user - in real app from session
    const currentUserId = "user_sale_1";

    const conversation = await db.conversation.findUnique({ where: { id: conversation_id } });
    if (!conversation) return NextResponse.json({ error: "Conversation not found" }, { status: 404 });

    const ownedBy = conversation.assigned_to_user_id || currentUserId;

    // Transaction Serializable FOR UPDATE to avoid race
    const order = await db.$transaction(async (tx: any) => {
      // Lock conversation row
      await tx.$queryRaw`SELECT * FROM "Conversation" WHERE id = ${conversation_id} FOR UPDATE`;

      const eventId = `DH-${Date.now()}_SUCCESS`;
      const fbp = conversation.fbp || "fb.1.1234567890.1234567890";
      const fbc = conversation.fbc || "fb.1.1234567890.IwAR...";

      const created = await tx.order.create({
        data: {
          id: `DH-${Date.now()}`,
          conversation_id,
          customer_id: conversation.customer_id,
          page_id: conversation.page_id,
          ad_id: conversation.ad_id,
          created_by_user_id: currentUserId,
          owned_by_user_id: ownedBy,
          items_json: items,
          total_amount,
          status: "PENDING",
          is_ready_for_shipping: false,
          capi_event_id: eventId,
          fbp,
          fbc,
          external_id: conversation.customer_id,
          vnpost_idempotency_key: `DH-${Date.now()}`,
        },
      });

      await tx.conversation.update({ where: { id: conversation_id }, data: { has_order: true } });

      await tx.auditLog.create({
        data: {
          user_id: currentUserId,
          action: "CREATE_ORDER",
          target_type: "Order",
          target_id: created.id,
          metadata: { total_amount, items, capi_event_id: eventId },
        },
      });

      return created;
    }, { isolationLevel: "Serializable" as any });

    // Build CAPI payloads
    const primaryPayload = buildPrimary({
      total_amount: order.total_amount,
      fb_catalog_id: items[0]?.fb_catalog_id || "default_catalog",
      price: items[0]?.price || total_amount,
      fbc: order.fbc || undefined,
      fbp: order.fbp || undefined,
      external_id: order.external_id || undefined,
      event_id: order.capi_event_id!,
      phone,
    });

    const fanoutPayload = buildFanout({
      phone: phone || "0912345123",
      event_id: order.capi_event_id!,
      fbc: order.fbc || undefined,
      fbp: order.fbp || undefined,
      external_id: order.external_id || undefined,
    });

    // Queue both with same event_id for dedup
    await addCapiJob({ orderId: order.id, eventId: order.capi_event_id!, type: "PRIMARY_FULL", payload: primaryPayload });
    await addCapiJob({ orderId: order.id, eventId: order.capi_event_id!, type: "FANOUT_LITE", payload: fanoutPayload });

    return NextResponse.json(order);
  } catch (e: any) {
    console.error(e);
    return NextResponse.json({ error: e.message }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const pageId = searchParams.get("page_id");
  const currentUserId = searchParams.get("current_user_id") || "user_sale_1";
  const role = searchParams.get("role") || "SALE";

  const where: any = {};
  if (pageId) where.page_id = pageId;
  // SALE only see own orders
  if (role === "SALE") where.owned_by_user_id = currentUserId;

  const orders = await db.order.findMany({ where, orderBy: { created_at: "desc" }, take: 50 });
  return NextResponse.json(orders);
}
