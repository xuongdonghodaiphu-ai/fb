import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { encrypt } from "@/lib/encrypt";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const company_id = searchParams.get("company_id");
  const where: any = { is_active: true };
  if (company_id) where.company_id = company_id;
  const pages = await db.page.findMany({ where, orderBy: { created_at: "desc" } });
  // Mask token
  const masked = pages.map((p: any) => ({ ...p, access_token_encrypted: "***" }));
  return NextResponse.json(masked);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { name, avatar_url, access_token, company_id, industry, primary_dataset_id } = body;
  if (!name || !access_token || !company_id) return NextResponse.json({ error: "Missing fields" }, { status: 400 });

  const encrypted = encrypt(access_token);
  const page = await db.page.create({
    data: { name, avatar_url, access_token_encrypted: encrypted, company_id, industry, primary_dataset_id, health_status: "HEALTHY" },
  });
  return NextResponse.json(page);
}
