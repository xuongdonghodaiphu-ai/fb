import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q");
  const where: any = { is_active: true };
  if (q) where.OR = [{ name: { contains: q, mode: "insensitive" } }, { sku: { contains: q, mode: "insensitive" } }];
  const products = await db.product.findMany({ where, take: 100, orderBy: { created_at: "desc" } });
  return NextResponse.json(products);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { sku, name, price, stock, fb_catalog_id } = body;
  const p = await db.product.create({ data: { sku, name, price, stock: stock || 0, fb_catalog_id, fb_sync_status: "SYNCED" } });
  return NextResponse.json(p);
}

export async function PUT(req: NextRequest) {
  const body = await req.json();
  const { id, price, stock, name } = body;
  const updated = await db.product.update({ where: { id }, data: { price, stock, name } });
  return NextResponse.json(updated);
}
