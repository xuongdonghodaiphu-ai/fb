import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { canViewSalary } from "@/lib/permissions";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const targetUserId = searchParams.get("user_id");
  const currentUserId = searchParams.get("current_user_id") || "user_sale_1";
  const role = (searchParams.get("role") || "SALE") as any;

  if (!targetUserId) return NextResponse.json({ error: "user_id required" }, { status: 400 });

  if (!canViewSalary(role, targetUserId, currentUserId)) {
    return NextResponse.json({ error: "Forbidden - own-only" }, { status: 403 });
  }

  const user = await db.user.findUnique({ where: { id: targetUserId } });
  if (!user) return NextResponse.json({ error: "User not found" }, { status: 404 });

  // Calculate commission this month
  const orders = await db.order.findMany({ where: { owned_by_user_id: targetUserId, created_at: { gte: new Date(new Date().getFullYear(), new Date().getMonth(), 1) } } });
  const totalSales = orders.reduce((s: number, o: any) => s + o.total_amount, 0);
  const commission = totalSales * user.commission_rate;

  return NextResponse.json({ salary_base: user.salary_base, commission_rate: user.commission_rate, totalSales, commission, total: user.salary_base + commission, ordersCount: orders.length });
}
