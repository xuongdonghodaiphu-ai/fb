import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function GET() {
  const tags = await db.tag.findMany({ where: { is_active: true }, orderBy: { created_at: "desc" } });
  return NextResponse.json(tags);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { name, color, type, auto_assign_rule } = body;
  if (!name) return NextResponse.json({ error: "Name required" }, { status: 400 });

  const tag = await db.tag.create({
    data: { name, color: color || "#22c55e", type: type || "MANUAL", auto_assign_rule },
  });

  await db.auditLog.create({ data: { action: "CREATE_TAG", target_type: "Tag", target_id: tag.id, metadata: { name, color } } });

  return NextResponse.json(tag);
}

export async function PUT(req: NextRequest) {
  const body = await req.json();
  const { id, name, color, is_active } = body;
  const updated = await db.tag.update({ where: { id }, data: { name, color, is_active } });
  return NextResponse.json(updated);
}

export async function DELETE(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const id = searchParams.get("id");
  if (!id) return NextResponse.json({ error: "id required" }, { status: 400 });
  await db.tag.update({ where: { id }, data: { is_active: false } });
  return NextResponse.json({ success: true });
}
