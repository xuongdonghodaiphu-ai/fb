import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { addVnpostJob } from "@/lib/queue";

export async function POST(req: NextRequest) {
  const idempotencyKey = req.headers.get("Idempotency-Key") || req.headers.get("idempotency-key");
  if (!idempotencyKey) return NextResponse.json({ error: "Idempotency-Key header required DH-xxx" }, { status: 400 });

  const body = await req.json();
  const { order_id } = body;

  const order = await db.order.findUnique({ where: { id: order_id } });
  if (!order) return NextResponse.json({ error: "Order not found" }, { status: 404 });

  // Check existing vnpost_code for idempotency
  if (order.vnpost_code && order.vnpost_idempotency_key === idempotencyKey) {
    return NextResponse.json({ message: "Already shipped", vnpost_code: order.vnpost_code });
  }

  // Queue job with idempotency
  await addVnpostJob({ orderId: order_id, idempotencyKey, payload: body });

  return NextResponse.json({ message: "Queued VNPost", idempotencyKey });
}

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const orderId = searchParams.get("order_id");
  if (!orderId) return NextResponse.json({ error: "order_id required" }, { status: 400 });
  const order = await db.order.findUnique({ where: { id: orderId } });
  return NextResponse.json({ vnpost_code: order?.vnpost_code, status: order?.status });
}
