import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function POST(req: NextRequest) {
  const body = await req.json();
  // CAPI feedback webhook from FB
  console.log("[CAPI Webhook]", JSON.stringify(body).slice(0, 1000));
  const { event_id, status } = body;
  if (event_id) {
    await db.capiLog.create({ data: { event_id, event_name: "Purchase", type: "WEBHOOK_FEEDBACK", payload: body, response: body, status: status || "FEEDBACK" } });
  }
  return NextResponse.json({ success: true });
}

export async function GET() {
  return NextResponse.json({ ok: true, message: "CAPI webhook alive - FB OS v3.1 FINAL" });
}
