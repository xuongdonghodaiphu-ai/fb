import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { extractPhone } from "@/lib/phoneExtractor";
import { extractAdId } from "@/lib/fbAdExtractor";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const mode = searchParams.get("hub.mode");
  const token = searchParams.get("hub.verify_token");
  const challenge = searchParams.get("hub.challenge");
  if (mode === "subscribe" && token === process.env.FB_VERIFY_TOKEN) {
    return new NextResponse(challenge, { status: 200 });
  }
  return NextResponse.json({ error: "Verification failed" }, { status: 403 });
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  console.log("[FB Webhook]", JSON.stringify(body).slice(0, 1000));

  // Simplified: handle messaging events
  const entries = body.entry || [];
  for (const entry of entries) {
    const pageId = entry.id;
    const messaging = entry.messaging || [];
    for (const event of messaging) {
      const senderId = event.sender?.id;
      const message = event.message?.text || "";
      const hasPhone = extractPhone(message).length > 0;
      const adId = extractAdId(message) || event.ad_id || null;

      // Upsert conversation
      const convId = `${pageId}_${senderId}`;
      await db.conversation.upsert({
        where: { id: convId },
        update: { last_message_content: message.slice(0, 500), last_message_at: new Date(), has_phone: hasPhone || undefined, ad_id: adId || undefined },
        create: {
          id: convId,
          page_id: pageId,
          customer_id: senderId,
          customer_name: `Customer ${senderId.slice(-4)}`,
          last_message_content: message.slice(0, 500),
          last_message_at: new Date(),
          has_phone: hasPhone,
          ad_id: adId || undefined,
          fbp: event.fbp || undefined,
          fbc: event.fbc || undefined,
          status: "OPEN",
        },
      });
    }
  }

  return NextResponse.json({ success: true });
}
