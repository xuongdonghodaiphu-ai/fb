"use client";
export default function ChatArea() {
  return (
    <div className="flex-1 flex flex-col bg-[#f0f2f5]">
      <div className="flex-1 overflow-auto p-4 space-y-3">
        <div className="bg-yellow-100 border border-yellow-300 text-[12px] px-3 py-2 rounded-lg">⚠️ Phát hiện số điện thoại 0912345123 - Lưu số</div>
        <div className="flex"><div className="bubble bg-white shadow-sm">Chị lấy size M nhé, SĐT 0912345123</div></div>
        <div className="flex justify-end"><div className="bubble bg-[#0084ff] text-white">Dạ ok chị, 780k ạ</div></div>
      </div>
      <div className="bg-white p-3 border-t flex gap-2">
        <input className="flex-1 bg-[#f0f2f5] rounded-full px-4 py-2 text-sm" placeholder="Nhập tin nhắn..." />
        <button className="bg-[#0084ff] text-white px-4 py-2 rounded-full text-sm">Gửi</button>
      </div>
    </div>
  );
}
