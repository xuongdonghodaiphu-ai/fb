"use client";
type Conv = { id: string; name: string; last: string; time: string; avatar: string; hasPhone?: boolean; hasOrder?: boolean };

export default function ConversationList({ items, activeId, onSelect }: { items: Conv[]; activeId: string; onSelect: (id: string) => void }) {
  return (
    <div className="flex-1 overflow-auto">
      {items.map((c) => (
        <div key={c.id} onClick={() => onSelect(c.id)} className={`flex gap-2 p-3 border-b cursor-pointer hover:bg-[#f0f2f5] ${activeId === c.id ? "bg-[#e7f3ff]" : "bg-white"}`}>
          <div className="w-10 h-10 rounded-full bg-[#e4e6eb] flex items-center justify-center text-xs font-bold">{c.avatar}</div>
          <div className="flex-1 min-w-0">
            <div className="flex justify-between">
              <span className="font-medium text-[13px] truncate max-w-[180px]">{c.name}</span>
              <span className="text-[11px] text-gray-500">{c.time}</span>
            </div>
            <div className="text-[12px] text-gray-600 truncate max-w-[220px]">{c.last}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
