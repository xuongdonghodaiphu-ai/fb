"use client";
import { useState } from "react";

export default function OrderForm({ conversationId }: { conversationId: string }) {
  const [items, setItems] = useState([{ sku: "AO-DA-M-001", qty: 1, price: 780000 }]);
  const total = items.reduce((s, it) => s + it.qty * it.price, 0);

  const submit = async () => {
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ conversation_id: conversationId, items, total_amount: total, phone: "0912345123", address: "123 Cầu Giấy" }),
    });
    const data = await res.json();
    alert("Tạo đơn " + data.id + " event " + data.capi_event_id + " is_ready=false owned_by assigned_to");
  };

  return (
    <div className="border rounded-xl p-3 bg-white">
      <div className="font-semibold text-sm mb-2">Tạo đơn - PENDING is_ready=false</div>
      {items.map((it, idx) => (
        <div key={idx} className="flex gap-2 text-xs mb-1">
          <span>{it.sku}</span>
          <span>x{it.qty}</span>
          <span>{it.price.toLocaleString()} VND</span>
        </div>
      ))}
      <div className="text-sm font-medium mt-2">Tổng: {total.toLocaleString()} VND - Transaction Serializable FOR UPDATE</div>
      <button onClick={submit} className="mt-2 w-full bg-[#0084ff] text-white rounded-lg py-2 text-sm">Tạo đơn + CAPI Primary FULL + Fanout LITE same event_id</button>
    </div>
  );
}
