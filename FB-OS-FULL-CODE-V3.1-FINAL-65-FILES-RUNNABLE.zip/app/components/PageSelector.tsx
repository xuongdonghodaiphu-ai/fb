"use client";
import { useState, useMemo } from "react";

type Page = { id: string; name: string; unread: number; avatar?: string; adAccount?: string };

const MOCK_PAGES: Page[] = [
  { id: "page_1", name: "Áo Dạ Cao Cấp - Thời Trang Nữ Hà Nội 2024", unread: 87, adAccount: "TKQC 1 - 132 chưa đọc", avatar: "AD" },
  { id: "page_2", name: "Túi Xách Authentic - Sale Sập Sàn Cuối Năm", unread: 45, adAccount: "TKQC 2 - 45 chưa đọc", avatar: "TX" },
];

export default function PageSelector({ selectedIds, onChange }: { selectedIds: string[]; onChange: (ids: string[]) => void }) {
  const [open, setOpen] = useState(false);
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    return MOCK_PAGES.filter((p) => p.name.toLowerCase().includes(search.toLowerCase()));
  }, [search]);

  const totalUnread = MOCK_PAGES.reduce((s, p) => s + p.unread, 0);
  const toggle = (id: string) => {
    if (selectedIds.includes(id)) onChange(selectedIds.filter((x) => x !== id));
    else onChange([...selectedIds, id]);
  };

  const truncate20 = (s: string) => (s.length > 20 ? s.slice(0, 20) + "..." : s);

  return (
    <div className="relative border-b p-2 bg-white">
      <button onClick={() => setOpen(!open)} className="w-full flex items-center justify-between bg-[#f0f2f5] rounded-lg px-3 py-2 text-sm">
        <span className="flex items-center gap-2 truncate max-w-[220px]">
          <span className="w-6 h-6 bg-blue-500 text-white rounded-full flex items-center justify-center text-[10px]">2</span>
          <span className="truncate-20">{selectedIds.length} trang đã chọn ({totalUnread} chưa đọc)</span>
        </span>
        <span>▼</span>
      </button>

      {open && (
        <div className="absolute left-2 right-2 top-[48px] bg-white rounded-xl shadow-2xl border z-50 overflow-hidden">
          <div className="p-2">
            <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Tìm trang..." className="w-full border rounded-lg px-3 py-1.5 text-sm" />
          </div>
          <div className="max-h-[320px] overflow-auto">
            {filtered.map((p) => (
              <label key={p.id} className="page-row px-3 hover:bg-[#f0f2f5] cursor-pointer flex gap-2">
                <input type="checkbox" checked={selectedIds.includes(p.id)} onChange={() => toggle(p.id)} className="w-4 h-4" />
                <div className="w-10 h-10 rounded-full bg-[#e4e6eb] flex items-center justify-center text-sm font-bold">{p.avatar}</div>
                <div className="flex-1 min-w-0">
                  <div className="text-[13px] font-medium truncate max-w-[220px]">{truncate20(p.name)}</div>
                  <div className="flex items-center gap-1">
                    <span className="badge-tkqc truncate max-w-[100px]">{p.adAccount}</span>
                    <span className="text-[11px] text-red-500">{p.unread} chưa đọc</span>
                  </div>
                </div>
              </label>
            ))}
          </div>
          <div className="p-2 border-t flex gap-2">
            <button className="flex-1 bg-[#0084ff] text-white rounded-lg py-1.5 text-sm">Gộp trang</button>
            <button onClick={() => setOpen(false)} className="flex-1 bg-[#e4e6eb] rounded-lg py-1.5 text-sm">Đóng</button>
          </div>
        </div>
      )}
    </div>
  );
}
