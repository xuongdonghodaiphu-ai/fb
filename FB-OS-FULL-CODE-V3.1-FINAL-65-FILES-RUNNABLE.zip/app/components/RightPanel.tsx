"use client";
export default function RightPanel() {
  return (
    <div className="w-[340px] bg-white border-l p-3 space-y-3 overflow-auto">
      <div className="border rounded-xl p-3">
        <div className="font-semibold text-sm">SĐT: ***123 [Nhấn để xem]</div>
        <p className="text-[11px] text-gray-500">Log VIEW_PHONE</p>
      </div>
      <div className="border rounded-xl p-3">
        <div className="font-semibold text-sm">Tín hiệu quảng cáo Đa nguồn</div>
        <div className="mt-2 space-y-1 text-xs">
          <div>ROAS 1.8 - Dataset 123 FULL 780k - ID DH-123_SUCCESS</div>
          <div>Dataset 999 LITE không giá trị - same event_id dedup</div>
        </div>
      </div>
    </div>
  );
}
