"use client";
import { useState, useEffect } from "react";

export default function SearchInput({ onSearch }: { onSearch: (q: string) => void }) {
  const [q, setQ] = useState("");
  useEffect(() => {
    const t = setTimeout(() => onSearch(q), 300);
    return () => clearTimeout(t);
  }, [q, onSearch]);
  return <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm hội thoại, SĐT, tên..." className="w-full bg-[#f0f2f5] rounded-full px-4 py-2 text-sm" />;
}
