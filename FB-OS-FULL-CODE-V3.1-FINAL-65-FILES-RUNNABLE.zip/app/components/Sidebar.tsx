"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const ITEMS = [
  { href: "/inbox", icon: "📥", label: "Inbox" },
  { href: "/orders", icon: "📦", label: "Đơn hàng" },
  { href: "/stats", icon: "📊", label: "Thống kê" },
  { href: "/settings", icon: "⚙️", label: "Cài đặt" },
];

export default function Sidebar() {
  const pathname = usePathname();
  return (
    <div className="w-[60px] bg-[#1c1e21] flex flex-col items-center py-4 gap-2 h-screen">
      <div className="w-10 h-10 bg-[#0084ff] rounded-xl flex items-center justify-center text-white font-bold text-sm mb-4">FB</div>
      {ITEMS.map((it) => {
        const active = pathname.startsWith(it.href);
        return (
          <Link key={it.href} href={it.href} className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg transition ${active ? "bg-white text-black" : "bg-[#3a3b3c] text-white hover:bg-[#4a4b4c]"}`} title={it.label}>
            {it.icon}
          </Link>
        );
      })}
      <div className="mt-auto w-8 h-8 rounded-full bg-gray-400" />
    </div>
  );
}
