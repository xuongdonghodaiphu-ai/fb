"use client";
import { useState, useMemo } from "react";

type Tag = { id: string; name: string; color: string };

export const DEFAULT_TAGS: Tag[] = [
  { id: "1", name: "Khách mới", color: "#22c55e" },
  { id: "2", name: "Đã tư vấn", color: "#3b82f6" },
  { id: "3", name: "Có SĐT", color: "#a855f7" },
  { id: "4", name: "Có đơn", color: "#f97316" },
  { id: "5", name: "VIP", color: "#eab308" },
  { id: "6", name: "Bom hàng", color: "#ef4444" },
  { id: "7", name: "Cần tư vấn lại", color: "#9ca3af" },
  { id: "8", name: "Áo dạ", color: "#ec4899" },
  { id: "9", name: "Túi xách", color: "#06b6d4" },
];

export default function TagSelector({ selected, onToggle }: { selected: string[]; onToggle: (id: string) => void }) {
  const [q, setQ] = useState("");
  const filtered = useMemo(() => DEFAULT_TAGS.filter((t) => t.name.toLowerCase().includes(q.toLowerCase())), [q]);

  return (
    <div className="bg-white rounded-xl border p-3">
      <div className="font-semibold text-sm mb-2">Thẻ (9 mẫu)</div>
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Tìm thẻ..." className="w-full border rounded-lg px-2 py-1 text-sm mb-2" />
      <div className="flex flex-wrap gap-1.5 max-h-[200px] overflow-auto">
        {filtered.map((t) => {
          const active = selected.includes(t.id);
          return (
            <button key={t.id} onClick={() => t && onToggle(t.id)} className={`flex items-center gap-1 px-2.5 py-1 rounded-full text-[12px] border transition ${active ? "text-white" : "bg-white"}`} style={{ background: active ? t.color : "white", borderColor: t.color, color: active ? "white" : t.color }}>
              <span className="w-2 h-2 rounded-full" style={{ background: active ? "white" : t.color }} />
              {t.name}
            </button>
          );
        })}
      </div>
      <div className="mt-3 flex gap-1 flex-wrap">
        {selected.map((id) => {
          const tag = DEFAULT_TAGS.find((t) => t.id === id);
          if (!tag) return null;
          return (
            <span key={id} className="px-2 py-0.5 rounded-full text-[11px] text-white" style={{ background: tag.color }}>
              {tag.name}
            </span>
          );
        })}
      </div>
      <p className="text-[11px] text-gray-500 mt-2">Log AuditLog ASSIGN_TAG khi gán thẻ</p>
    </div>
  );
}
