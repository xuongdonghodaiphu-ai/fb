"use client";
export default function AdSignalCard({ adId, roas, datasetId, type, value, eventId }: { adId: string; roas: number; datasetId: string; type: "FULL" | "LITE"; value?: number; eventId: string }) {
  return (
    <div className="bg-white border rounded-lg p-2.5 text-xs space-y-1">
      <div className="flex justify-between">
        <span className="font-medium">Ad {adId}</span>
        <span className={`px-1.5 py-0.5 rounded text-[10px] ${type === "FULL" ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-600"}`}>{type}</span>
      </div>
      <div>ROAS {roas} - Dataset {datasetId} - {type === "FULL" ? `${value?.toLocaleString()} VND` : "không giá trị"}</div>
      <div className="text-[11px] text-gray-500">ID {eventId} - {type === "FULL" ? "Primary FULL contents [{id:fb_catalog_id, quantity:1, item_price:price}] + content_ids + fbc fbp external_id" : "Fanout LITE chỉ ph + same event_id dedup 1 doanh số 2 tín hiệu"}</div>
    </div>
  );
}
