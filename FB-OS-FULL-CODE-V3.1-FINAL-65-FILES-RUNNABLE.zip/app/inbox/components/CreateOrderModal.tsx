"use client";
import { useState } from "react";

type Product = { sku: string; name: string; price: number; fb_catalog_id: string };

const PRODUCTS: Product[] = [
  { sku: "AO-DA-M-001", name: "Áo dạ M", price: 780000, fb_catalog_id: "ao_da_M_001" },
  { sku: "TUI-XACH-DEN", name: "Túi xách đen", price: 450000, fb_catalog_id: "tui_xach_den_001" },
];

export default function CreateOrderModal({ open, onClose, conversationId }: { open: boolean; onClose: () => void; conversationId: string }) {
  const [selected, setSelected] = useState<Product[]>([PRODUCTS[0]]);
  const [address, setAddress] = useState("123 Cầu Giấy, Hà Nội");
  const [phone, setPhone] = useState("0912345123");

  const total = selected.reduce((s, p) => s + p.price, 0);

  const handleCreate = async () => {
    const res = await fetch("/api/orders", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        conversation_id: conversationId,
        items: selected.map((p) => ({ sku: p.sku, qty: 1, price: p.price, fb_catalog_id: p.fb_catalog_id })),
        total_amount: total,
        phone,
        address,
      }),
    });
    const data = await res.json();
    alert("Tạo đơn thành công: " + data.id + " event_id " + data.capi_event_id);
    onClose();
  };

  if (!open) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-white rounded-2xl w-[480px] p-5">
        <h3 className="font-semibold text-lg mb-3">Tạo đơn hàng - {conversationId}</h3>
        <div className="space-y-3">
          <div>
            <label className="text-xs">Sản phẩm</label>
            <div className="border rounded-lg p-2 max-h-[120px] overflow-auto">
              {PRODUCTS.map((p) => (
                <label key={p.sku} className="flex items-center gap-2 text-sm py-1">
                  <input type="checkbox" checked={selected.some((s) => s.sku === p.sku)} onChange={(e) => setSelected((prev) => (e.target.checked ? [...prev, p] : prev.filter((x) => x.sku !== p.sku)))} />
                  {p.name} - {p.price.toLocaleString()} VND - {p.fb_catalog_id}
                </label>
              ))}
            </div>
          </div>
          <div>
            <label className="text-xs">SĐT</label>
            <input value={phone} onChange={(e) => setPhone(e.target.value)} className="w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
          <div>
            <label className="text-xs">Địa chỉ</label>
            <input value={address} onChange={(e) => setAddress(e.target.value)} className="w-full border rounded-lg px-3 py-2 text-sm" />
          </div>
          <div className="text-sm font-medium">Tổng: {total.toLocaleString()} VND - PENDING is_ready=false owned_by assigned_to</div>
        </div>
        <div className="flex gap-2 mt-4">
          <button onClick={handleCreate} className="flex-1 bg-[#0084ff] text-white rounded-lg py-2 text-sm">Tạo đơn DH-xxx_SUCCESS</button>
          <button onClick={onClose} className="flex-1 bg-[#e4e6eb] rounded-lg py-2 text-sm">Hủy</button>
        </div>
      </div>
    </div>
  );
}
