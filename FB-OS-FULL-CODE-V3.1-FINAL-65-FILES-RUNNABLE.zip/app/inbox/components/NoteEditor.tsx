"use client";
import { useState } from "react";

export default function NoteEditor({ conversationId }: { conversationId: string }) {
  const [note, setNote] = useState("");
  const save = async () => {
    await fetch(`/api/conversations/${conversationId}/notes`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ content: note }) });
    alert("Đã lưu ghi chú nội bộ");
    setNote("");
  };
  return (
    <div className="border rounded-xl p-3 bg-white">
      <div className="font-semibold text-sm mb-2">Ghi chú nội bộ - {conversationId}</div>
      <textarea value={note} onChange={(e) => setNote(e.target.value)} className="w-full border rounded-lg p-2 text-sm h-[80px]" placeholder="Nhập ghi chú cho sale..." />
      <button onClick={save} className="mt-2 w-full bg-[#0084ff] text-white rounded-lg py-1.5 text-sm">Lưu ghi chú</button>
      <p className="text-[11px] text-gray-500 mt-1">Chỉ nội bộ, khách không thấy</p>
    </div>
  );
}
