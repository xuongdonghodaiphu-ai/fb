"use client";
export default function OrderDetail({ order }: { order: any }) {
  if (!order) return <div className="p-3 text-sm text-gray-500">Chưa có đơn</div>;
  return (
    <div className="border rounded-xl p-3 bg-white space-y-2">
      <div className="font-semibold text-sm">Đơn {order.id} - {order.status}</div>
      <div className="text-xs">Tổng: {order.total_amount?.toLocaleString()} VND</div>
      <div className="text-xs">VNPost: {order.vnpost_code || "Chưa gửi"} - Idempotency: {order.vnpost_idempotency_key}</div>
      <div className="text-xs">CAPI Event: {order.capi_event_id} - fbp {order.fbp} fbc {order.fbc}</div>
      <div className="text-xs">Owned by: {order.owned_by_user_id} - Created by: {order.created_by_user_id}</div>
      <div className="text-xs">Items: {JSON.stringify(order.items_json)}</div>
      <div className="text-xs">is_ready_for_shipping: {String(order.is_ready_for_shipping)}</div>
    </div>
  );
}
