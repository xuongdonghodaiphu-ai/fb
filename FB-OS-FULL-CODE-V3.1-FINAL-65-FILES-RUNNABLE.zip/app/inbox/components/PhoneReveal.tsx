"use client";
import { useState } from "react";
import { maskPhone } from "../../../lib/phoneExtractor";

export default function PhoneReveal({ phone, conversationId }: { phone: string; conversationId: string }) {
  const [revealed, setRevealed] = useState(false);

  const reveal = async () => {
    // Log VIEW_PHONE
    await fetch("/api/audit-logs", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: "VIEW_PHONE", target_id: conversationId, metadata: { phone: maskPhone(phone) } }),
    });
    setRevealed(true);
  };

  return (
    <div className="flex items-center gap-2 text-sm">
      <span>SĐT: {revealed ? phone : maskPhone(phone)}</span>
      {!revealed && (
        <button onClick={reveal} className="text-blue-600 underline text-xs">
          [Nhấn để xem]
        </button>
      )}
      <span className="text-[11px] text-gray-500">Chặn + log AuditLog VIEW_PHONE khi nhấn</span>
    </div>
  );
}
