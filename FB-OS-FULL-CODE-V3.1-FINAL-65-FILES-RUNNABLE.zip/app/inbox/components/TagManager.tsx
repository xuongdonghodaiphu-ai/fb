"use client";
import { useState } from "react";
import { DEFAULT_TAGS } from "../../components/TagSelector";

export default function TagManager({ conversationId }: { conversationId: string }) {
  const [tags, setTags] = useState(DEFAULT_TAGS);
  const [newName, setNewName] = useState("");
  const [newColor, setNewColor] = useState("#22c55e");

  const createTag = async () => {
    if (!newName) return;
    const res = await fetch("/api/tags", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: newName, color: newColor }) });
    const data = await res.json();
    setTags([...tags, data]);
    setNewName("");
  };

  const assign = async (tagId: string) => {
    await fetch(`/api/conversations/${conversationId}/tags`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ tag_id: tagId }) });
    alert("Đã gán thẻ + log AuditLog ASSIGN_TAG");
  };

  return (
    <div className="border rounded-xl p-3 bg-white">
      <div className="font-semibold text-sm mb-2">Quản lý thẻ - {conversationId}</div>
      <div className="flex gap-2 mb-3">
        <input value={newName} onChange={(e) => setNewName(e.target.value)} placeholder="Tên thẻ mới" className="flex-1 border rounded-lg px-2 py-1 text-sm" />
        <input type="color" value={newColor} onChange={(e) => setNewColor(e.target.value)} className="w-8 h-8" />
        <button onClick={createTag} className="bg-[#0084ff] text-white px-3 py-1 rounded-lg text-xs">Tạo</button>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {tags.map((t) => (
          <button key={t.id} onClick={() => assign(t.id)} className="px-2.5 py-1 rounded-full text-xs text-white" style={{ background: t.color }}>
            {t.name}
          </button>
        ))}
      </div>
    </div>
  );
}
