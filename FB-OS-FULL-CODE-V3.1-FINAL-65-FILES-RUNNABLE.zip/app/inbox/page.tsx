"use client";
import { useState } from "react";
import PageSelector from "../components/PageSelector";
import TagSelector, { DEFAULT_TAGS } from "../components/TagSelector";

type Conv = { id: string; name: string; last: string; time: string; unread?: number; hasPhone?: boolean; hasOrder?: boolean; avatar: string };

const CONVS: Conv[] = [
  { id: "LA", name: "Lan Anh - Áo Dạ 45kg", last: "0912345123 chị lấy size M nhé shop...", time: "2p", unread: 2, hasPhone: true, hasOrder: false, avatar: "LA" },
  { id: "MT", name: "Minh Tú - Túi Xách Đen", last: "Còn hàng không em? chị cần gấp...", time: "5p", hasPhone: true, hasOrder: true, avatar: "MT" },
  { id: "HG", name: "Hương Giang - Bom hàng", last: "Chị không nhận nữa nhé...", time: "10p", unread: 1, hasPhone: true, avatar: "HG" },
  { id: "TA", name: "Tuấn Anh - VIP", last: "Ok chốt đơn 2 cái, ship luôn nhé", time: "15p", hasOrder: true, avatar: "TA" },
  { id: "PL", name: "Phương Linh - Cần tư vấn lại", last: "Để chị suy nghĩ thêm đã...", time: "1h", avatar: "PL" },
];

export default function InboxPage() {
  const [selectedPages, setSelectedPages] = useState<string[]>(["page_1", "page_2"]);
  const [filter, setFilter] = useState("Tất cả");
  const [activeConv, setActiveConv] = useState<Conv>(CONVS[0]);
  const [selectedTags, setSelectedTags] = useState<string[]>(["1", "3"]);
  const [showPhone, setShowPhone] = useState(false);

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#f0f2f5]">
      {/* Sidebar 60px #1c1e21 */}
      <div className="w-[60px] bg-[#1c1e21] flex flex-col items-center py-4 gap-4">
        <div className="w-10 h-10 bg-[#0084ff] rounded-xl flex items-center justify-center text-white font-bold">FB</div>
        <div className="w-10 h-10 bg-[#3a3b3c] rounded-xl flex items-center justify-center">📥</div>
        <div className="w-10 h-10 bg-[#3a3b3c] rounded-xl flex items-center justify-center">📦</div>
        <div className="w-10 h-10 bg-[#3a3b3c] rounded-xl flex items-center justify-center">📊</div>
      </div>

      {/* List 360px */}
      <div className="w-[360px] bg-white border-r flex flex-col">
        <PageSelector selectedIds={selectedPages} onChange={setSelectedPages} />
        <div className="p-2 border-b">
          <input placeholder="Tìm hội thoại..." className="w-full bg-[#f0f2f5] rounded-full px-4 py-2 text-sm" />
          <div className="flex gap-1 mt-2 overflow-x-auto">
            {["Tất cả", "Chưa đọc", "Chưa tạo đơn", "Có số điện"].map((f) => (
              <button key={f} onClick={() => setFilter(f)} className={`whitespace-nowrap px-3 py-1 rounded-full text-[12px] border ${filter === f ? "bg-[#0084ff] text-white border-[#0084ff]" : "bg-white"}`}>
                {f}
              </button>
            ))}
          </div>
        </div>
        <div className="flex-1 overflow-auto">
          {CONVS.map((c) => (
            <div key={c.id} onClick={() => setActiveConv(c)} className={`flex gap-2 p-3 border-b cursor-pointer hover:bg-[#f0f2f5] ${activeConv.id === c.id ? "bg-[#e7f3ff]" : ""}`}>
              <div className="w-10 h-10 rounded-full bg-[#e4e6eb] flex items-center justify-center text-xs font-bold">{c.avatar}</div>
              <div className="flex-1 min-w-0">
                <div className="flex justify-between">
                  <span className="font-medium text-[13px] truncate">{c.name}</span>
                  <span className="text-[11px] text-gray-500">{c.time}</span>
                </div>
                <div className="text-[12px] text-gray-600 truncate">{c.last}</div>
                <div className="flex gap-1 mt-1">
                  {c.hasPhone && <span className="text-[10px] bg-purple-100 text-purple-600 px-1.5 py-0.5 rounded">Có SĐT</span>}
                  {c.hasOrder && <span className="text-[10px] bg-orange-100 text-orange-600 px-1.5 py-0.5 rounded">Có đơn</span>}
                  {c.unread && <span className="text-[10px] bg-red-500 text-white px-1.5 py-0.5 rounded-full">{c.unread}</span>}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Chat center */}
      <div className="flex-1 flex flex-col bg-[#f0f2f5]">
        <div className="h-[56px] bg-white border-b flex items-center px-4 justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-gray-200 flex items-center justify-center text-xs">{activeConv.avatar}</div>
            <span className="font-medium text-sm">{activeConv.name}</span>
          </div>
          <div className="text-xs text-gray-500">ID: {activeConv.id}-PSID-789</div>
        </div>

        <div className="flex-1 overflow-auto p-4 space-y-3">
          <div className="flex justify-center">
            <span className="bg-white text-[11px] px-2 py-1 rounded-full text-gray-500">Hôm nay</span>
          </div>
          <div className="bg-yellow-100 border border-yellow-300 text-[12px] px-3 py-2 rounded-lg">
            ⚠️ Phát hiện số điện thoại: <b>0912345123</b> - <button className="underline text-blue-600">Lưu số</button> | Banner vàng Phát hiện số
          </div>
          <div className="flex">
            <div className="bubble bg-white">Chị ơi em có áo dạ size M không ạ? 0912345123 chị lấy size M nhé shop, ship về Hà Nội ạ</div>
          </div>
          <div className="flex justify-end">
            <div className="bubble bg-[#0084ff] text-white">Dạ có chị ơi, em còn size M ạ, 780k chị nhé, chị cho em xin địa chỉ ạ?</div>
          </div>
          <div className="flex">
            <div className="bubble bg-white">Ok chốt, chị ở 123 Cầu Giấy nhé</div>
          </div>
        </div>

        <div className="bg-white p-3 border-t">
          <div className="flex gap-2">
            <input placeholder="Nhập tin nhắn..." className="flex-1 bg-[#f0f2f5] rounded-full px-4 py-2 text-sm" />
            <button className="bg-[#0084ff] text-white px-4 py-2 rounded-full text-sm">Gửi</button>
          </div>
        </div>
      </div>

      {/* Right panel 340px */}
      <div className="w-[340px] bg-white border-l overflow-auto p-3 space-y-3">
        <div className="border rounded-xl p-3">
          <div className="font-semibold text-sm mb-2">Thông tin khách hàng</div>
          <div className="text-sm">SĐT: {showPhone ? "0912345123" : "***123"} <button onClick={() => setShowPhone(!showPhone)} className="text-blue-600 underline text-xs">[Nhấn để xem]</button></div>
          <p className="text-[11px] text-gray-500 mt-1">Chặn + log Audit VIEW_PHONE khi nhấn xem</p>
          <div className="mt-2 text-xs">Địa chỉ: 123 Cầu Giấy, Hà Nội</div>
        </div>

        <TagSelector selected={selectedTags} onToggle={(id) => setSelectedTags((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]))} />

        <div className="border rounded-xl p-3">
          <div className="font-semibold text-sm mb-2">Ghi chú nội bộ</div>
          <textarea className="w-full border rounded-lg p-2 text-sm h-[80px]" placeholder="Nhập ghi chú..."></textarea>
          <button className="mt-2 w-full bg-[#e4e6eb] rounded-lg py-1.5 text-sm">Lưu ghi chú</button>
        </div>

        <div className="border rounded-xl p-3 bg-[#fffbeb]">
          <div className="font-semibold text-sm mb-2">Tín hiệu quảng cáo - Đa nguồn</div>
          <div className="space-y-2">
            <div className="bg-white border rounded-lg p-2 text-xs">
              <div className="font-medium">ROAS 1.8 - Ad 238467...</div>
              <div className="text-gray-500">Chi phí 120k / Doanh thu 216k</div>
            </div>
            <div className="bg-white border rounded-lg p-2 text-xs">
              <div className="font-medium">Dataset 123 FULL 780k</div>
              <div>ID DH-123_SUCCESS - Primary FULL với value</div>
              <div className="text-green-600">fb_catalog_id: áo_dạ_M_001</div>
            </div>
            <div className="bg-white border rounded-lg p-2 text-xs">
              <div className="font-medium">Dataset 999 LITE không giá trị</div>
              <div>ID DH-123_SUCCESS - Fanout LITE chỉ ph, same event_id</div>
              <div className="text-gray-500">Dedup 1 doanh số 2 tín hiệu</div>
            </div>
          </div>
        </div>

        <div className="border rounded-xl p-3">
          <div className="font-semibold text-sm mb-2">Đơn hàng DH-123</div>
          <div className="text-xs space-y-1">
            <div>Tổng: 780.000 VND</div>
            <div>Trạng thái: PENDING - is_ready=false</div>
            <div>VNPost: VNPOST_123 - Idempotency DH-123</div>
            <div>Owned by: assigned_to_user_id</div>
          </div>
        </div>
      </div>
    </div>
  );
}
