import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "FB Inbox OS v3.1 FINAL",
  description: "Inbox OS - Fix 1128 files limit - 65 files runnable port 6000",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="vi">
      <body className="bg-[#f0f2f5] text-[#050505] antialiased">
        {children}
      </body>
    </html>
  );
}
