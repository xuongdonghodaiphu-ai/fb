import { useState, useEffect, useCallback } from "react";

type UseInboxOptions = {
  pageIds: string[];
  filter: string;
  search: string;
};

export function useInbox(opts: UseInboxOptions) {
  const [conversations, setConversations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);

  const fetchConversations = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: String(page),
        limit: "20",
        ...(opts.pageIds.length ? { page_id: opts.pageIds[0] } : {}),
        ...(opts.filter === "Có số điện" ? { has_phone: "true" } : {}),
        ...(opts.filter === "Chưa tạo đơn" ? { has_order: "false" } : {}),
        ...(opts.search ? { q: opts.search } : {}),
      });
      const res = await fetch(`/api/conversations?${params}`);
      const data = await res.json();
      setConversations(data.items || []);
      setTotal(data.total || 0);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, [opts.pageIds, opts.filter, opts.search, page]);

  useEffect(() => {
    fetchConversations();
  }, [fetchConversations]);

  const lockConversation = async (id: string, userId: string) => {
    // Lock 5 phút
    const lockedUntil = new Date(Date.now() + 5 * 60 * 1000);
    setConversations((prev) => prev.map((c) => (c.id === id ? { ...c, locked_by_user_id: userId, locked_until: lockedUntil, is_locked: true } : c)));
  };

  return { conversations, loading, total, page, setPage, fetchConversations, lockConversation };
}
