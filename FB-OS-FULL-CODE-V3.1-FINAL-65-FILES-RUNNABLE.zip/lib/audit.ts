import { db } from "./db";

export type AuditAction = "VIEW_PHONE" | "CREATE_ORDER" | "ASSIGN_TAG" | "CREATE_TAG" | "UPDATE_ORDER" | "LOGIN" | "VIEW_SALARY";

export async function logAudit(params: { userId?: string; action: AuditAction; targetType?: string; targetId?: string; metadata?: any }) {
  try {
    await db.auditLog.create({
      data: {
        user_id: params.userId,
        action: params.action,
        target_type: params.targetType,
        target_id: params.targetId,
        metadata: params.metadata,
      },
    });
  } catch (e) {
    console.error("Audit log failed", e);
  }
}

export async function getAuditLogs(filter: { userId?: string; action?: string; from?: Date; to?: Date }) {
  const where: any = {};
  if (filter.userId) where.user_id = filter.userId;
  if (filter.action) where.action = filter.action;
  if (filter.from && filter.to) where.created_at = { gte: filter.from, lte: filter.to };
  return db.auditLog.findMany({ where, orderBy: { created_at: "desc" }, take: 100 });
}
