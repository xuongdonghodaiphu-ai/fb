import CryptoJS from "crypto-js";

export function sha256Lower(input: string): string {
  return CryptoJS.SHA256(input.trim().toLowerCase()).toString(CryptoJS.enc.Hex);
}

export function hashPhone(raw: string): string {
  if (!raw) return "";
  // Normalize: remove spaces, dashes, parens
  let phone = raw.replace(/[^0-9+]/g, "");
  // Handle +84, 84, 0...
  if (phone.startsWith("+84")) {
    phone = "0" + phone.slice(3);
  } else if (phone.startsWith("84") && phone.length >= 11) {
    phone = "0" + phone.slice(2);
  }
  // Must start with 0 and 10 digits VN
  if (!phone.startsWith("0")) phone = "0" + phone;
  // Final normalized 0xxxxxxxxx -> convert to 84 for hashing? FB expects raw digits hashed, we keep 0 format but lower
  // FB docs: hash phone with country code removed spaces, keep as is lower trimmed
  // We hash the normalized 0xxx
  return sha256Lower(phone);
}

export function hashEmail(email: string): string {
  if (!email) return "";
  return sha256Lower(email.trim().toLowerCase());
}

type BuildPrimaryInput = {
  total_amount: number;
  fb_catalog_id: string;
  price: number;
  fbc?: string;
  fbp?: string;
  external_id?: string;
  event_id: string; // DH-123_SUCCESS
  phone?: string;
  email?: string;
};

export function buildPrimary(input: BuildPrimaryInput) {
  const { total_amount, fb_catalog_id, price, fbc, fbp, external_id, event_id, phone, email } = input;
  const user_data: any = {};
  if (phone) user_data.ph = [hashPhone(phone)];
  if (email) user_data.em = [hashEmail(email)];
  if (fbc) user_data.fbc = fbc;
  if (fbp) user_data.fbp = fbp;
  if (external_id) user_data.external_id = [sha256Lower(external_id)];

  return {
    data: [
      {
        event_name: "Purchase",
        event_time: Math.floor(Date.now() / 1000),
        event_id: event_id,
        event_source_url: "https://fb.com/inbox",
        action_source: "business_messaging",
        user_data,
        custom_data: {
          value: total_amount,
          currency: "VND",
          contents: [{ id: fb_catalog_id, quantity: 1, item_price: price }],
          content_ids: [fb_catalog_id],
          content_type: "product",
        },
      },
    ],
  };
}

type BuildFanoutInput = {
  phone: string;
  event_id: string; // SAME as primary for dedup
  fbc?: string;
  fbp?: string;
  external_id?: string;
};

export function buildFanout(input: BuildFanoutInput) {
  const { phone, event_id, fbc, fbp, external_id } = input;
  const user_data: any = {
    ph: [hashPhone(phone)],
  };
  if (fbc) user_data.fbc = fbc;
  if (fbp) user_data.fbp = fbp;
  if (external_id) user_data.external_id = [sha256Lower(external_id)];

  return {
    data: [
      {
        event_name: "Purchase",
        event_time: Math.floor(Date.now() / 1000),
        event_id: event_id, // SAME ID => dedup 1 revenue 2 signals
        event_source_url: "https://fb.com/inbox",
        action_source: "business_messaging",
        user_data,
        custom_data: {
          // LITE: no value, no contents, no price
          currency: "VND",
        },
      },
    ],
  };
}
