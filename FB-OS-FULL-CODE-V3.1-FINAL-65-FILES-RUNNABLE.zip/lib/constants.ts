export const APP_NAME = "FB Inbox OS v3.1 FINAL";
export const PORT = 6000;
export const PAGE_SIZE = 20;
export const LOCK_DURATION_MINUTES = 5;
export const PHONE_REGEX = /(?:\+84|84|0)[1-9][0-9]{8,9}/g;
export const ROLES = ["OWNER", "MANAGER", "SALE", "SHIPPER"] as const;
export const ORDER_STATUS = ["PENDING", "CONFIRMED", "SHIPPING", "DELIVERED", "CANCELLED", "BOM"] as const;
export const CAPI_EVENT_ID_PREFIX = "DH";
export const VNPOST_IDEMPOTENCY_PREFIX = "DH";

export const TAG_COLORS = {
  "Khách mới": "#22c55e",
  "Đã tư vấn": "#3b82f6",
  "Có SĐT": "#a855f7",
  "Có đơn": "#f97316",
  "VIP": "#eab308",
  "Bom hàng": "#ef4444",
  "Cần tư vấn lại": "#9ca3af",
  "Áo dạ": "#ec4899",
  "Túi xách": "#06b6d4",
};

export const STATS_DEFAULT = {
  phat_tc: 72.3,
  hoan: 8.1,
  huy: 16.0,
  bom: 24.1,
  roas: 1.8,
};
