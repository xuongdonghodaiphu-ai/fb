import { PrismaClient } from "@prisma/client";

declare global {
  // eslint-disable-next-line no-var
  var prisma: PrismaClient | undefined;
}

const prismaClientSingleton = () => {
  return new PrismaClient({
    log: process.env.NODE_ENV === "development" ? ["query", "error", "warn"] : ["error"],
  });
};

export const db = globalThis.prisma ?? prismaClientSingleton();

if (process.env.NODE_ENV !== "production") {
  globalThis.prisma = db;
}

export default db;

// Helper for transaction with Serializable isolation
export async function serializableTransaction<T>(fn: (tx: any) => Promise<T>) {
  return db.$transaction(fn, { isolationLevel: "Serializable" as any, timeout: 10000 });
}
