import crypto from "crypto";

const ALGO = "aes-256-gcm";
const IV_LENGTH = 12;
const AUTH_TAG_LENGTH = 16;

function getKey(): Buffer {
  const keyHex = process.env.ENCRYPT_KEY;
  if (!keyHex) throw new Error("ENCRYPT_KEY missing");
  // Support 32 char string or 64 hex
  if (keyHex.length === 64) return Buffer.from(keyHex, "hex");
  // Pad/hash to 32 bytes
  return crypto.createHash("sha256").update(keyHex).digest();
}

export function encrypt(text: string): string {
  const key = getKey();
  const iv = crypto.randomBytes(IV_LENGTH);
  const cipher = crypto.createCipheriv(ALGO, key, iv);
  const encrypted = Buffer.concat([cipher.update(text, "utf8"), cipher.final()]);
  const authTag = cipher.getAuthTag();
  // Format: iv:authTag:encrypted all base64
  return `${iv.toString("base64") }:${authTag.toString("base64") }:${encrypted.toString("base64") }`;
}

export function decrypt(payload: string): string {
  const key = getKey();
  const [ivB64, authTagB64, encB64] = payload.split(":");
  if (!ivB64 || !authTagB64 || !encB64) throw new Error("Invalid encrypted payload");
  const iv = Buffer.from(ivB64, "base64");
  const authTag = Buffer.from(authTagB64, "base64");
  const encrypted = Buffer.from(encB64, "base64");
  const decipher = crypto.createDecipheriv(ALGO, key, iv);
  decipher.setAuthTag(authTag);
  const decrypted = Buffer.concat([decipher.update(encrypted), decipher.final()]);
  return decrypted.toString("utf8");
}

export function encryptToken(token: string) {
  return encrypt(token);
}

export function decryptToken(enc: string) {
  try {
    return decrypt(enc);
  } catch {
    return "";
  }
}
