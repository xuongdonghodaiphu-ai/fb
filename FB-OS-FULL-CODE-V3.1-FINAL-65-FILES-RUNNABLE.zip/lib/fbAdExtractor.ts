// Extract FB ad_id, campaign, page from message / fbp fbc

export function extractAdId(text: string): string | null {
  if (!text) return null;
  // fb ad id pattern 2384...
  const patterns = [
    /ad_id[=\s:]+([0-9]{10,20})/i,
    /fb_ad_([0-9]{10,20})/i,
    /\b(2384[0-9]{8,15})\b/,
  ];
  for (const p of patterns) {
    const m = text.match(p);
    if (m) return m[1] || m[0];
  }
  return null;
}

export function extractCampaign(text: string): string | null {
  if (!text) return null;
  const m = text.match(/campaign[=\s:]+([^\s,;]+)/i);
  return m ? m[1] : null;
}

export function extractPage(text: string): string | null {
  if (!text) return null;
  const m = text.match(/page[=\s:]+([0-9]+)/i);
  return m ? m[1] : null;
}

export function parseFbc(fbc?: string) {
  if (!fbc) return null;
  // fbc format: fb.1.1234567890.Iw...
  const parts = fbc.split(".");
  return {
    version: parts[0],
    subdomainIndex: parts[1],
    creationTime: parts[2],
    fbclid: parts[3],
  };
}

export function parseFbp(fbp?: string) {
  if (!fbp) return null;
  // fbp format: fb.1.1234567890.1234567890
  const parts = fbp.split(".");
  return {
    version: parts[0],
    subdomainIndex: parts[1],
    creationTime: parts[2],
    randomNumber: parts[3],
  };
}

export function extractAdSignals(message: string, fbc?: string, fbp?: string) {
  return {
    ad_id: extractAdId(message),
    fbc_parsed: parseFbc(fbc),
    fbp_parsed: parseFbp(fbp),
    has_paid_signal: !!(extractAdId(message) || fbc || fbp),
  };
}
