type LogLevel = "info" | "warn" | "error" | "debug";

function log(level: LogLevel, message: string, meta?: any) {
  const timestamp = new Date().toISOString();
  const line = `[${timestamp}] [${level.toUpperCase()}] ${message} ${meta ? JSON.stringify(meta).slice(0, 500) : ""}`;
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export const logger = {
  info: (msg: string, meta?: any) => log("info", msg, meta),
  warn: (msg: string, meta?: any) => log("warn", msg, meta),
  error: (msg: string, meta?: any) => log("error", msg, meta),
  debug: (msg: string, meta?: any) => log("debug", msg, meta),
};

export function auditLog(action: string, userId?: string, targetId?: string, metadata?: any) {
  logger.info(`AUDIT ${action}`, { userId, targetId, metadata });
}
