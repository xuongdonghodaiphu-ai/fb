export const Role = {
  OWNER: "OWNER",
  MANAGER: "MANAGER",
  SALE: "SALE",
  SHIPPER: "SHIPPER",
} as const;

export type RoleType = (typeof Role)[keyof typeof Role];

export function canViewAll(role: RoleType): boolean {
  return role === Role.OWNER || role === Role.MANAGER;
}

export function canViewPhone(role: RoleType, isOwnerOfConv?: boolean): boolean {
  if (role === Role.OWNER || role === Role.MANAGER) return true;
  if (role === Role.SALE && isOwnerOfConv) return true;
  return false;
}

export function canEditPrice(role: RoleType): boolean {
  return role === Role.OWNER || role === Role.MANAGER;
}

export function canAssignTag(role: RoleType): boolean {
  return role !== Role.SHIPPER;
}

export function canViewSalary(role: RoleType, targetUserId?: string, currentUserId?: string): boolean {
  if (role === Role.OWNER) return true;
  if (targetUserId && currentUserId && targetUserId === currentUserId) return true; // own-only
  return false;
}

export function maskPhoneForRole(phone: string, role: RoleType, isOwner?: boolean): string {
  if (canViewPhone(role, isOwner)) return phone;
  if (!phone) return "***";
  // *** + last 3
  return "***" + phone.slice(-3);
}

export function canCreateOrder(role: RoleType): boolean {
  return role === Role.OWNER || role === Role.MANAGER || role === Role.SALE;
}

export function canViewStats(role: RoleType): boolean {
  return role === Role.OWNER || role === Role.MANAGER;
}
