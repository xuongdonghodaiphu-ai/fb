import { db } from "./db";

const PHONE_REGEX = /(?:\+84|84|0)(?:[0-9]{9,10})/g;
const PHONE_STRICT = /(?:\+84|84|0)[1-9][0-9]{8,9}/;

export function extractPhone(text: string): string[] {
  if (!text) return [];
  const matches = text.match(PHONE_REGEX);
  if (!matches) return [];
  // Deduplicate and normalize
  const uniq = Array.from(new Set(matches.map((m) => m.replace(/[^0-9+]/g, ""))));
  return uniq.filter((p) => PHONE_STRICT.test(p));
}

export function maskPhone(phone: string): string {
  if (!phone) return "***";
  const clean = phone.replace(/\s/g, "");
  if (clean.length <= 3) return "***" + clean;
  return "***" + clean.slice(-3);
}

export async function logPhoneView(params: { userId: string; conversationId: string; phone: string }) {
  const { userId, conversationId, phone } = params;
  try {
    await db.auditLog.create({
      data: {
        user_id: userId,
        action: "VIEW_PHONE",
        target_type: "Conversation",
        target_id: conversationId,
        metadata: { phone: maskPhone(phone), full: false },
      },
    });
  } catch (e) {
    console.error("Failed to log VIEW_PHONE", e);
  }
}

export function hasPhoneNumber(text: string): boolean {
  return extractPhone(text).length > 0;
}
