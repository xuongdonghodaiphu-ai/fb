import { Queue, Worker, QueueEvents } from "bullmq";
import { redisConnection } from "./redis";

export const CAPI_QUEUE = "capi-fanout-queue";
export const VNPOST_QUEUE = "vnpost-queue";

export const capiQueue = new Queue(CAPI_QUEUE, {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 3,
    backoff: { type: "exponential", delay: 5000 },
    removeOnComplete: 100,
    removeOnFail: 50,
  },
});

export const vnpostQueue = new Queue(VNPOST_QUEUE, {
  connection: redisConnection,
  defaultJobOptions: {
    attempts: 5,
    backoff: { type: "exponential", delay: 10000 },
    removeOnComplete: 50,
    removeOnFail: 20,
  },
});

export async function addCapiJob(data: { orderId: string; eventId: string; type: "PRIMARY_FULL" | "FANOUT_LITE"; payload: any }) {
  return capiQueue.add(`capi-${data.type}-${data.orderId}`, data, {
    jobId: `${data.eventId}-${data.type}`,
  });
}

export async function addVnpostJob(data: { orderId: string; idempotencyKey: string; payload: any }) {
  return vnpostQueue.add(`vnpost-${data.orderId}`, data, {
    jobId: data.idempotencyKey,
  });
}
