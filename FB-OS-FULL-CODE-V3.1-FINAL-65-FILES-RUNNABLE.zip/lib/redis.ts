import IORedis from "ioredis";

const redisUrl = process.env.REDIS_URL || "redis://localhost:6379";

declare global {
  var redis: IORedis | undefined;
}

export const redis = globalThis.redis ?? new IORedis(redisUrl, { maxRetriesPerRequest: null });

if (process.env.NODE_ENV !== "production") globalThis.redis = redis;

export const redisConnection = redis as any;

// Helpers
export async function setLock(key: string, ttlSec: number, owner: string) {
  return redis.set(key, owner, "EX", ttlSec, "NX");
}

export async function releaseLock(key: string, owner: string) {
  const val = await redis.get(key);
  if (val === owner) await redis.del(key);
}

export async function getCached<T>(key: string): Promise<T | null> {
  const v = await redis.get(key);
  if (!v) return null;
  try {
    return JSON.parse(v) as T;
  } catch {
    return null;
  }
}

export async function setCached(key: string, value: any, ttlSec = 60) {
  await redis.set(key, JSON.stringify(value), "EX", ttlSec);
}
