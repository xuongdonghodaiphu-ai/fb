import crypto from "crypto";

export function generateIdempotencyKey(prefix = "DH") {
  return `${prefix}-${Date.now()}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`;
}

export function sanitizeInput(input: string): string {
  if (!input) return "";
  return input
    .replace(/[<>]/g, "")
    .slice(0, 5000)
    .trim();
}

export function validatePhone(phone: string): boolean {
  const regex = /^(0|\+84|84)[0-9]{9,10}$/;
  return regex.test(phone.replace(/\s/g, ""));
}

export function rateLimitKey(userId: string, action: string) {
  return `ratelimit:${userId}:${action}`;
}

export function maskSensitive(obj: any) {
  const copy = { ...obj };
  if (copy.phone) copy.phone = "***" + String(copy.phone).slice(-3);
  if (copy.access_token) copy.access_token = "***";
  if (copy.access_token_encrypted) copy.access_token_encrypted = "***";
  return copy;
}
