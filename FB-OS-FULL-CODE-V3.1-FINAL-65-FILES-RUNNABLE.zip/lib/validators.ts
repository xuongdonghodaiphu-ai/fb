import { z } from "zod";

export const createOrderSchema = z.object({
  conversation_id: z.string().min(1),
  items: z.array(z.object({ sku: z.string(), qty: z.number().min(1), price: z.number().min(0), fb_catalog_id: z.string().optional() })).min(1),
  total_amount: z.number().min(1000),
  phone: z.string().regex(/^(0|\+84|84)[0-9]{9,10}$/),
  address: z.string().min(5).max(500),
});

export const createTagSchema = z.object({
  name: z.string().min(1).max(50),
  color: z.string().regex(/^#[0-9a-fA-F]{6}$/),
  type: z.enum(["MANUAL", "AUTO"]).default("MANUAL"),
});

export const createPageSchema = z.object({
  name: z.string().min(1).max(100),
  access_token: z.string().min(10),
  company_id: z.string().min(1),
});

export function validate(schema: z.ZodSchema, data: any) {
  const result = schema.safeParse(data);
  if (!result.success) return { valid: false, errors: result.error.errors };
  return { valid: true, data: result.data };
}
