import { PrismaClient } from "@prisma/client";
import { encrypt } from "../lib/encrypt";

const db = new PrismaClient();

async function main() {
  console.log("Seeding FB OS v3.1 FINAL 65 files...");

  const companyId = "company_001";

  const page1 = await db.page.upsert({
    where: { id: "page_1" },
    update: {},
    create: {
      id: "page_1",
      name: "Áo Dạ Cao Cấp - Thời Trang Nữ Hà Nội 2024",
      avatar_url: "https://example.com/avatar1.jpg",
      access_token_encrypted: encrypt("EAAG_test_token_page_1"),
      company_id: companyId,
      industry: "Fashion",
      primary_dataset_id: "123456789012345",
      health_status: "HEALTHY",
      is_active: true,
    },
  });

  const dataset1 = await db.fbDataset.upsert({
    where: { dataset_id: "123456789012345" },
    update: {},
    create: { dataset_id: "123456789012345", name: "Dataset 123 FULL", company_id: companyId, industry: "Fashion", access_token: "EAAG_dataset_123", is_active: true },
  });

  const dataset2 = await db.fbDataset.upsert({
    where: { dataset_id: "999999999999999" },
    update: {},
    create: { dataset_id: "999999999999999", name: "Dataset 999 LITE", company_id: companyId, industry: "Fashion", access_token: "EAAG_dataset_999", is_active: true },
  });

  const owner = await db.user.upsert({
    where: { email: "owner@fbos.vn" },
    update: {},
    create: { email: "owner@fbos.vn", name: "Owner", role: "OWNER", salary_base: 10000000, commission_rate: 0.1, is_active: true },
  });

  const sale1 = await db.user.upsert({
    where: { email: "sale1@fbos.vn" },
    update: {},
    create: { email: "sale1@fbos.vn", name: "Sale 1 - Lan Anh", role: "SALE", salary_base: 5000000, commission_rate: 0.05, is_active: true },
  });

  const tags = [
    { name: "Khách mới", color: "#22c55e" },
    { name: "Đã tư vấn", color: "#3b82f6" },
    { name: "Có SĐT", color: "#a855f7" },
    { name: "Có đơn", color: "#f97316" },
    { name: "VIP", color: "#eab308" },
    { name: "Bom hàng", color: "#ef4444" },
    { name: "Cần tư vấn lại", color: "#9ca3af" },
    { name: "Áo dạ", color: "#ec4899" },
    { name: "Túi xách", color: "#06b6d4" },
  ];

  for (const t of tags) {
    await db.tag.upsert({ where: { name: t.name }, update: {}, create: { name: t.name, color: t.color, type: "MANUAL", is_active: true } });
  }

  const product = await db.product.upsert({
    where: { sku: "AO-DA-M-001" },
    update: {},
    create: { sku: "AO-DA-M-001", name: "Áo dạ M 2024", price: 780000, stock: 100, fb_catalog_id: "ao_da_M_001", fb_sync_status: "SYNCED", is_active: true },
  });

  console.log("Seed done - Page:", page1.id, "Datasets:", dataset1.dataset_id, dataset2.dataset_id, "Owner:", owner.email);
}

main().catch((e) => { console.error(e); process.exit(1); }).finally(async () => { await db.$disconnect(); });
