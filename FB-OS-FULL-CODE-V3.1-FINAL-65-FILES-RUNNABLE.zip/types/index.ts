export type Page = {
  id: string;
  name: string;
  avatar_url?: string;
  health_status: "HEALTHY" | "WARNING" | "BANNED";
  access_token_encrypted: string;
  company_id: string;
  industry?: string;
  primary_dataset_id?: string;
  is_active: boolean;
  created_at: Date;
};

export type FbDataset = {
  id: string;
  dataset_id: string;
  name: string;
  company_id: string;
  industry?: string;
  access_token: string;
  is_active: boolean;
};

export type UserRole = "OWNER" | "MANAGER" | "SALE" | "SHIPPER";

export type User = {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  salary_base: number;
  commission_rate: number;
  is_active: boolean;
};

export type Tag = {
  id: string;
  name: string;
  color: string;
  type: "MANUAL" | "AUTO";
  auto_assign_rule?: any;
  is_active: boolean;
  created_at: Date;
};

export type Conversation = {
  id: string;
  page_id: string;
  customer_id: string;
  customer_name?: string;
  assigned_to_user_id?: string;
  last_message_content?: string;
  last_message_at: Date;
  status: "OPEN" | "DONE" | "SPAM";
  has_phone: boolean;
  has_order: boolean;
  locked_by_user_id?: string;
  locked_until?: Date;
  ad_id?: string;
  fbp?: string;
  fbc?: string;
};

export type Product = {
  id: string;
  sku: string;
  name: string;
  price: number;
  stock: number;
  fb_catalog_id?: string;
  fb_sync_status: string;
  is_active: boolean;
};

export type Order = {
  id: string;
  conversation_id: string;
  customer_id: string;
  page_id: string;
  ad_id?: string;
  created_by_user_id: string;
  owned_by_user_id: string;
  items_json: any;
  total_amount: number;
  status: "PENDING" | "CONFIRMED" | "SHIPPING" | "DELIVERED" | "CANCELLED" | "BOM";
  vnpost_code?: string;
  vnpost_idempotency_key?: string;
  is_ready_for_shipping: boolean;
  capi_event_id?: string;
  fbp?: string;
  fbc?: string;
  external_id?: string;
  created_at: Date;
};

export type AdSignal = {
  ad_id?: string;
  campaign?: string;
  roas: number;
  dataset_id: string;
  type: "FULL" | "LITE";
  value?: number;
  event_id: string;
};
