import axios from "axios";
import { db } from "../lib/db";

type CapiJobData = {
  orderId: string;
  eventId: string; // DH-xxx_SUCCESS same for PRIMARY and FANOUT
  type: "PRIMARY_FULL" | "FANOUT_LITE";
  payload: any;
};

export async function handleCapiFanout(data: CapiJobData) {
  const { orderId, eventId, type, payload } = data;
  const pixelId = process.env.CAPI_PIXEL_ID || "123456789012345";
  const accessToken = process.env.CAPI_ACCESS_TOKEN || "test_token";

  // Dedup: 1 doanh số 2 tín hiệu nhờ same event_id
  // Primary FULL: value + contents [{id:fb_catalog_id, quantity:1, item_price:price}] + content_ids + fbc fbp + external_id
  // Fanout LITE: chỉ ph + same event_id, không giá trị

  const url = `https://graph.facebook.com/v18.0/${pixelId}/events?access_token=${accessToken}`;

  try {
    // Log attempt
    await db.capiLog.create({
      data: { event_id: eventId, event_name: "Purchase", type, payload, status: "PENDING" },
    });

    const response = await axios.post(url, payload, { timeout: 10000 });
    const result = response.data;

    await db.capiLog.create({
      data: { event_id: eventId, event_name: "Purchase", type, payload, response: result, status: "SUCCESS" },
    });

    console.log(`[CAPI ${type}] Success event_id ${eventId} order ${orderId}`, result);

    // If PRIMARY, update order capi sent
    if (type === "PRIMARY_FULL") {
      await db.order.update({ where: { id: orderId }, data: { status: "CONFIRMED" } as any });
    }

    return result;
  } catch (e: any) {
    console.error(`[CAPI ${type}] Failed`, e.message);
    await db.capiLog.create({
      data: { event_id: eventId, event_name: "Purchase", type, payload, response: { error: e.message }, status: "FAILED" },
    });
    throw e;
  }
}
