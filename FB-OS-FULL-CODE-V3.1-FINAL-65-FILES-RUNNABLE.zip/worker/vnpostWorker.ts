import axios from "axios";
import { db } from "../lib/db";

type VnpostJobData = {
  orderId: string;
  idempotencyKey: string; // DH-xxx
  payload: any;
};

export async function handleVnpost(data: VnpostJobData) {
  const { orderId, idempotencyKey, payload } = data;
  const apiUrl = process.env.VNPOST_API_URL || "https://api.vnpost.vn/v1/orders";
  const token = process.env.VNPOST_TOKEN || "vnpost_test_token";

  // Check idempotency - if already shipped with same key, skip
  const existing = await db.order.findUnique({ where: { id: orderId } });
  if (existing?.vnpost_code && existing?.vnpost_idempotency_key === idempotencyKey) {
    console.log(`[VNPOST] Idempotent skip ${orderId} key ${idempotencyKey} code ${existing.vnpost_code}`);
    return { vnpost_code: existing.vnpost_code, idempotent: true };
  }

  try {
    // Real VNPost API call would be here - mock for demo
    const vnpostPayload = {
      order_id: orderId,
      idempotency_key: idempotencyKey,
      receiver: {
        phone: payload.phone || "0912345123",
        address: payload.address || "123 Cầu Giấy",
        name: payload.name || "Lan Anh",
      },
      items: existing?.items_json || [],
      cod_amount: existing?.total_amount || 780000,
    };

    // Simulate API call
    // const res = await axios.post(apiUrl, vnpostPayload, { headers: { Authorization: `Bearer ${token}`, "Idempotency-Key": idempotencyKey } });
    // const vnpostCode = res.data.code;

    const vnpostCode = `VNPOST_${Date.now()}`;

    await db.order.update({
      where: { id: orderId },
      data: { vnpost_code: vnpostCode, vnpost_idempotency_key: idempotencyKey, status: "SHIPPING", is_ready_for_shipping: true },
    });

    console.log(`[VNPOST] Shipped ${orderId} -> ${vnpostCode} with key ${idempotencyKey}`);

    return { vnpost_code: vnpostCode };
  } catch (e: any) {
    console.error("[VNPOST] Failed", e.message);
    throw e;
  }
}
