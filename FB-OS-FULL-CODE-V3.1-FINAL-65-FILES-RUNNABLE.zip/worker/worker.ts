import { Worker } from "bullmq";
import { redisConnection } from "../lib/redis";
import { CAPI_QUEUE, VNPOST_QUEUE } from "../lib/queue";
import { handleCapiFanout } from "./capiFanoutWorker";
import { handleVnpost } from "./vnpostWorker";

console.log("Starting workers for FB OS v3.1 FINAL - Port 6000 - 65 files");

const capiWorker = new Worker(
  CAPI_QUEUE,
  async (job) => {
    console.log(`[CAPI] Processing ${job.id} type ${job.data.type} event_id ${job.data.eventId}`);
    return handleCapiFanout(job.data);
  },
  { connection: redisConnection, concurrency: 5 }
);

const vnpostWorker = new Worker(
  VNPOST_QUEUE,
  async (job) => {
    console.log(`[VNPOST] Processing ${job.id} order ${job.data.orderId} idempotency ${job.data.idempotencyKey}`);
    return handleVnpost(job.data);
  },
  { connection: redisConnection, concurrency: 3 }
);

capiWorker.on("completed", (job) => console.log(`[CAPI] Completed ${job.id}`));
capiWorker.on("failed", (job, err) => console.error(`[CAPI] Failed ${job?.id}`, err));

vnpostWorker.on("completed", (job) => console.log(`[VNPOST] Completed ${job.id}`));
vnpostWorker.on("failed", (job, err) => console.error(`[VNPOST] Failed ${job?.id}`, err));

process.on("SIGTERM", async () => {
  await capiWorker.close();
  await vnpostWorker.close();
  process.exit(0);
});
